"""Fixed-composition MC with explicit equilibration and independent temperature starts.

Counts must be integral for the selected supercell. Each temperature starts with a
separately randomized configuration; heating/cooling studies need separate runs.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from ase.io import write
from icet import ClusterExpansion
from mchammer.calculators import ClusterExpansionCalculator
from mchammer.ensembles import CanonicalEnsemble
from mchammer.observers import ShortRangeOrderObserver


def decorate(structure, concentrations, seed):
    if any(x < 0 for x in concentrations.values()) or not np.isclose(sum(concentrations.values()), 1):
        raise ValueError("Concentrations must be nonnegative and sum to one")
    counts = {s: int(round(len(structure) * x)) for s, x in concentrations.items()}
    if sum(counts.values()) != len(structure) or any(
        not np.isclose(n, len(structure) * concentrations[s]) for s, n in counts.items()
    ):
        raise ValueError("This supercell cannot represent the requested exact composition")
    symbols = [s for s, n in counts.items() for _ in range(n)]
    np.random.default_rng(seed).shuffle(symbols)
    structure.set_chemical_symbols(symbols)
    return structure


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("model", type=Path)
    p.add_argument("composition", type=Path, help="JSON mapping symbols to fractions")
    p.add_argument("--repeat", nargs=3, type=int, default=[5, 5, 5])
    p.add_argument("--temperatures", nargs="+", type=float, default=[600, 1000, 1600])
    p.add_argument("--eq", type=int, default=500, help="Equilibration sweeps; only a starting value")
    p.add_argument("--sample", type=int, default=1000, help="Sampling sweeps; must check convergence")
    p.add_argument("--sro-radius", type=float, default=3.4, help="Max pair distance, Angstrom")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--out", type=Path, default=Path("canonical_runs"))
    a = p.parse_args()
    if min(a.repeat) < 1 or a.eq < 1 or a.sample < 2 or min(a.temperatures) <= 0:
        raise ValueError("Positive sizes, temperatures and run lengths are required")
    if a.out.exists():
        raise FileExistsError(f"Choose a new output directory: {a.out}")
    ce = ClusterExpansion.read(str(a.model))
    cs = ce.get_cluster_space_copy()
    composition = json.loads(a.composition.read_text(encoding="utf-8-sig"))
    a.out.mkdir(parents=True)
    for idx, temperature in enumerate(a.temperatures):
        seed = a.seed + idx
        atoms = decorate(ce.primitive_structure.repeat(a.repeat), composition, seed)
        cs.assert_structure_compatibility(atoms)
        if cs.is_supercell_self_interacting(atoms):
            raise ValueError("Increase --repeat to remove CE self-interaction")
        # Apply the same geometry check to the shells measured by the SRO observer.
        from icet import ClusterSpace
        sro_cs = ClusterSpace(ce.primitive_structure, [a.sro_radius], ce.chemical_symbols)
        if sro_cs.is_supercell_self_interacting(atoms):
            raise ValueError("Increase --repeat or reduce --sro-radius")
        n = len(atoms)
        stem = f"{idx:03d}_T{temperature:g}_seed{seed}"
        calc = ClusterExpansionCalculator(atoms, ce)
        mc = CanonicalEnsemble(atoms, calc, temperature=temperature,
             random_seed=seed, dc_filename=str(a.out / f"{stem}.dc"),
             ensemble_data_write_interval=n, trajectory_write_interval=100 * n)
        mc.attach_observer(ShortRangeOrderObserver(cs, atoms, radius=a.sro_radius, interval=10*n))
        mc.run(a.eq * n)
        production_start = mc.step
        mc.run(a.sample * n)
        mc.write_data_container(str(a.out / f"{stem}.dc"))
        write(str(a.out / f"{stem}_final.extxyz"), mc.structure)
        metadata = dict(temperature=temperature, n_atoms=n, seed=seed,
                        production_start=production_start, eq_sweeps=a.eq,
                        sample_sweeps=a.sample, energy_units="eV total in potential")
        (a.out / f"{stem}.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        print(stem, "finished; assess equilibration before interpreting results")


if __name__ == "__main__":
    main()

