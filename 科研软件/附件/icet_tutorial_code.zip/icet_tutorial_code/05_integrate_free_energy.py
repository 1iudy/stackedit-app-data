"""Integrate a binary VCSGC derivative curve; additive reference remains undetermined.

This script deliberately does not call the resulting curve an equilibrium phase diagram.
Check equilibration, size effects and references, then perform a common-tangent analysis.
"""
import argparse
from pathlib import Path
import numpy as np


def integrate_curve(c, derivative):
    c, derivative = np.asarray(c, dtype=float), np.asarray(derivative, dtype=float)
    if c.ndim != 1 or c.shape != derivative.shape or len(c) < 2:
        raise ValueError("Need at least two matching 1D arrays")
    if not np.all(np.isfinite(c)) or not np.all(np.isfinite(derivative)):
        raise ValueError("Non-finite input")
    order = np.argsort(c)
    c, derivative = c[order], derivative[order]
    if np.any(np.diff(c) <= 1e-10):
        raise ValueError("Concentrations are not distinct; handle saturated/duplicate points first")
    f = np.r_[0., np.cumsum(np.diff(c)*(derivative[:-1]+derivative[1:])/2)]
    return c, derivative, f


def main():
    import pandas as pd
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("scan", type=Path)
    a = p.parse_args()
    data = pd.read_csv(a.scan)
    if set(data["mode"]) != {"vcsgc"} or data.temperature_K.nunique() != 1:
        raise ValueError("Use a single-temperature VCSGC scan")
    c, derivative, f = integrate_curve(data.c, data.df_dc_eV_site)
    out = a.scan.with_name("free_energy_relative.csv")
    pd.DataFrame(dict(c=c, df_dc_eV_site=derivative, f_minus_f_at_cmin_eV_site=f)).to_csv(out, index=False)
    print(out, "Reference: f(c_min)=0. This is not an absolute inter-phase reference.")


if __name__ == "__main__":
    main()

