"""Print the installed versions and the public interfaces used by this tutorial."""
from importlib.metadata import version
from inspect import signature

for package in ("icet", "ase", "trainstation", "numpy", "scipy", "scikit-learn"):
    print(package, version(package))

from icet import ClusterSpace, ClusterExpansion, StructureContainer
from trainstation import CrossValidationEstimator
from mchammer.calculators import ClusterExpansionCalculator
from mchammer.ensembles import CanonicalEnsemble, SemiGrandCanonicalEnsemble, VCSGCEnsemble
from mchammer.observers import ShortRangeOrderObserver

for cls in (ClusterSpace, ClusterExpansion, StructureContainer,
            CrossValidationEstimator, ClusterExpansionCalculator,
            CanonicalEnsemble, SemiGrandCanonicalEnsemble, VCSGCEnsemble,
            ShortRangeOrderObserver):
    print(cls.__name__, signature(cls))

