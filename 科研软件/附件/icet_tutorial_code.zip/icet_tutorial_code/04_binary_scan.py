"""Binary single-sublattice SGC or VCSGC scan, using a supplied CE.

Every point starts independently. This is a workflow template, not a phase diagram.
Use 06_check_sgc_sign.py to confirm the installed SGC convention before analysis.
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from ase.units import kB
from icet import ClusterExpansion
from mchammer.calculators import ClusterExpansionCalculator
from mchammer.ensembles import SemiGrandCanonicalEnsemble, VCSGCEnsemble


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("model", type=Path)
    p.add_argument("--mode", choices=["sgc", "vcsgc"], default="vcsgc")
    p.add_argument("--species", nargs=2, default=["Ag", "Pd"], help="Reference, variable species")
    p.add_argument("--temperature", type=float, default=800)
    p.add_argument("--repeat", type=int, default=10)
    p.add_argument("--lower", type=float, default=-2.1)
    p.add_argument("--upper", type=float, default=0.1)
    p.add_argument("--points", type=int, default=23)
    p.add_argument("--kappa", type=float, default=200)
    p.add_argument("--eq", type=int, default=500)
    p.add_argument("--sample", type=int, default=1000)
    p.add_argument("--seed", type=int, default=200)
    p.add_argument("--out", type=Path, default=Path("binary_scan"))
    a = p.parse_args()
    if a.temperature <= 0 or a.kappa <= 0 or a.points < 2 or a.repeat < 1 or a.eq < 1 or a.sample < 2:
        raise ValueError("Invalid temperature, size or sampling settings")
    if a.out.exists():
        raise FileExistsError("Choose a new --out directory")
    ce = ClusterExpansion.read(str(a.model))
    if any(set(s) != set(a.species) for s in ce.chemical_symbols):
        raise ValueError("This script is restricted to a binary lattice with identical allowed species")
    cs = ce.get_cluster_space_copy()
    a.out.mkdir(parents=True)
    rows = []
    for idx, control in enumerate(np.linspace(a.lower, a.upper, a.points)):
        atoms = ce.primitive_structure.repeat(a.repeat)
        n = len(atoms)
        symbols = [a.species[1]]*(n//2) + [a.species[0]]*(n-n//2)
        np.random.default_rng(a.seed + idx).shuffle(symbols)
        atoms.set_chemical_symbols(symbols)
        if cs.is_supercell_self_interacting(atoms):
            raise ValueError("Increase --repeat")
        calc = ClusterExpansionCalculator(atoms, ce)
        path = a.out / f"{idx:03d}_{a.mode}.dc"
        common = dict(structure=atoms, calculator=calc, temperature=a.temperature,
                      random_seed=a.seed+idx, dc_filename=str(path),
                      ensemble_data_write_interval=n, trajectory_write_interval=100*n)
        if a.mode == "sgc":
            mc = SemiGrandCanonicalEnsemble(**common,
                 chemical_potentials={a.species[0]: 0., a.species[1]: float(control)})
        else:
            mc = VCSGCEnsemble(**common, phis={a.species[1]: float(control)}, kappa=a.kappa)
        mc.run(a.eq*n)
        mc.run(a.sample*n)
        mc.write_data_container(str(path))
        df = mc.data_container.data
        prod = df.loc[df.mctrial > a.eq*n]
        c = prod[f"{a.species[1]}_count"].mean()/n
        derivative = (control if a.mode == "sgc" else -kB*a.temperature*a.kappa*(2*c+control))
        rows.append(dict(mode=a.mode, temperature_K=a.temperature, control=control,
                         kappa=a.kappa if a.mode == "vcsgc" else np.nan,
                         c=c, df_dc_eV_site=derivative, energy_eV_site=prod.potential.mean()/n,
                         acceptance=prod.acceptance_ratio.mean(), seed=a.seed+idx))
        pd.DataFrame(rows).to_csv(a.out / "scan.csv", index=False)
        print(rows[-1])


if __name__ == "__main__":
    main()

