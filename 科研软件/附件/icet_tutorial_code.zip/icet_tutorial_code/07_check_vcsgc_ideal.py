"""Check VCSGC against the exact finite-N distribution of a zero-energy binary model.

The variance bias is positive in the effective energy, hence negative in log weight.
This is an interface/physics sanity check, not a real AgPd calculation.
"""
from math import lgamma
import numpy as np
from ase.build import bulk
from icet import ClusterSpace, ClusterExpansion
from mchammer.calculators import ClusterExpansionCalculator
from mchammer.ensembles import VCSGCEnsemble

primitive = bulk("Ag", "fcc", a=4.1)
cs = ClusterSpace(primitive, [3.0], ["Ag", "Pd"])
ce = ClusterExpansion(cs, np.zeros(len(cs)))
for idx, phi in enumerate([-1.4, -1.0, -0.6]):
    atoms = primitive.repeat(5)
    n = len(atoms)
    kappa = 10.
    counts = np.arange(n+1)
    log_omega = np.array([lgamma(n+1)-lgamma(int(m)+1)-lgamma(n-int(m)+1) for m in counts])
    log_weight = log_omega-kappa*n*(counts/n+phi/2)**2
    weight = np.exp(log_weight-log_weight.max())
    weight /= weight.sum()
    expected = np.sum(weight*counts/n)
    expected_var = np.sum(weight*(counts/n-expected)**2)
    calc = ClusterExpansionCalculator(atoms, ce)
    mc = VCSGCEnsemble(atoms, calc, temperature=1000., phis={"Pd": phi},
         kappa=kappa, random_seed=300+idx, ensemble_data_write_interval=n,
         trajectory_write_interval=1000*n)
    mc.run(100*n)
    mc.run(1000*n)
    data = mc.data_container.data
    observed = data.loc[data.mctrial > 100*n, "Pd_count"].to_numpy()/n
    print(dict(phi=phi, measured=observed.mean(), exact_mean=expected,
               measured_variance=observed.var(), exact_variance=expected_var))
    if abs(observed.mean()-expected) > 0.02:
        raise RuntimeError("VCSGC mean differs from the positive-penalty finite-N reference")
    if not 0.5 < observed.var()/expected_var < 1.5:
        raise RuntimeError("VCSGC variance differs: inspect implementation and sampling")

