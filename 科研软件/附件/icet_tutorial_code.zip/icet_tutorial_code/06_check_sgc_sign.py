"""Zero-Hamiltonian binary test of chemical-potential sign; no real material physics."""
import numpy as np
from ase.build import bulk
from ase.units import kB
from icet import ClusterSpace, ClusterExpansion
from mchammer.calculators import ClusterExpansionCalculator
from mchammer.ensembles import SemiGrandCanonicalEnsemble

primitive = bulk("Ag", "fcc", a=4.1)
cs = ClusterSpace(primitive, [3.0], ["Ag", "Pd"])
ce = ClusterExpansion(cs, np.zeros(len(cs)))
temperature = 1000.
for idx, dmu in enumerate([-0.1, 0., 0.1]):
    atoms = primitive.repeat(5)
    n = len(atoms)
    calc = ClusterExpansionCalculator(atoms, ce)
    mc = SemiGrandCanonicalEnsemble(atoms, calc, temperature=temperature,
         chemical_potentials={"Ag": 0., "Pd": dmu}, random_seed=100+idx,
         ensemble_data_write_interval=n, trajectory_write_interval=1000*n)
    mc.run(100*n)
    mc.run(1000*n)
    data = mc.data_container.data
    measured = data.loc[data.mctrial > 100*n, "Pd_count"].mean()/n
    expected = 1./(1.+np.exp(-dmu/(kB*temperature)))
    print(dict(dmu=dmu, measured=measured, ideal_expected=expected))
    if abs(measured-expected) > 0.03:
        raise RuntimeError("SGC convention or sampling differs: investigate before using the scan script")

