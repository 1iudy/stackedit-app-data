# icet 中文教程配套代码

目标文档：`icet_CE_MC高熵合金相稳定性教程.md`。官方资料核对日期为 2026-09-20；版本基线为 icet 4.0。

这些脚本是基于官方公开接口编写的教学模板，不包含 DFT 数据、已训练的材料模型或计算得到的相图。当前交付环境未安装 icet、ASE 或 trainstation；已做语法检查与独立积分单元检查，未做 icet 端到端运行。详见主文档第 21 节和 `verification.txt`。

## 先检查环境

在独立环境安装 `requirements.in` 中的依赖。源码安装 icet 可能需要 C++17 编译器。

```bash
python -m pip install -r requirements.in
python 00_check_environment.py
python 06_check_sgc_sign.py
python 07_check_vcsgc_ideal.py
```

后两个脚本使用人为设置为零的 Hamiltonian，分别检查化学势符号及 VCSGC 正惩罚偏置的统计分布。通过它们不代表真实材料模型已经验证。

## 训练

```bash
python 01_train.py /path/to/reference_data.db --out fit_agpd
```

默认约定仅针对官方 AgPd 数据库。自建数据库必须提供 `--primitive`、`--symbols`、`--cutoffs`、`--key`；结构须在理想母晶格上，能量字段须为 eV/site。完全占据的置换合金中 eV/site 等于 eV/atom。不要输入超胞总能量。

```bash
python 01_train.py training.db --primitive primitive.extxyz --symbols Nb Mo Ta W V --cutoffs 5.0 3.5 --key formation_energy_eV_atom --out fit_hea
python 02_canonical.py fit_hea/model.ce composition_hea.json --repeat 5 5 5 --temperatures 600 1000 1600 --sro-radius 3.4 --out hea_mc
python 03_analyze_canonical.py hea_mc
```

每个温度采用独立随机初态。默认平衡、采样长度以及超胞大小均为起点；不能据此宣称已经收敛。生产结果应补充多种子、初态、尺寸、升降温和模型不确定性验证。脚本要求新输出目录，避免意外使用旧模拟状态。

## 二元扫描

```bash
python 04_binary_scan.py fit_agpd/model.ce --mode vcsgc --temperature 800 --lower -2.1 --upper 0.1 --out vcsgc_T800
python 05_integrate_free_energy.py vcsgc_T800/scan.csv
```

SGC 模式需显式使用能量单位的化学势范围，例如 `--mode sgc --lower -0.5 --upper 0.3`。扫描脚本仅适用于单子晶格二元模型。

积分输出仅为相对自由能，不能单独当成相图。跨相比较需要共同参考；两相共存还需公切线/公共切平面、尺寸效应与必要的界面/应变分析。

## 数据分析限制

`fit_in_sample.csv` 是输入数据上的预测，不是外部测试集。

`03_analyze_canonical.py` 的热容公式仅适用于不显含温度的 Hamiltonian、正则系综和统一能量单位。热容没有自动生成 bootstrap 误差；`summary.csv` 中 SRO 也只输出均值。论文分析应另行补充相关性与误差条。

## 官方资源

- [icet 官网](https://icet.materialsmodeling.org/)
- [官方入门数据](https://icet.materialsmodeling.org/get_started/index.html)
- [官方 Notebook 教程](https://ce-tutorials.materialsmodeling.org/)
- [软件引用](https://doi.org/10.1002/adts.201900015)
- [教程论文](https://doi.org/10.1103/PRXEnergy.3.042001)
