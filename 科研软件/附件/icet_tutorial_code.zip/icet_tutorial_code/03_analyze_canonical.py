"""Summarize canonical trajectories; report fluctuation heat capacity and SRO.

The fluctuation formula assumes a temperature-independent Hamiltonian.
Use blocking/bootstrap across multiple seeds for publication-level uncertainties.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from ase.units import kB
from mchammer import DataContainer


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("directory", type=Path)
    a = p.parse_args()
    records = []
    for path in sorted(a.directory.glob("*.dc")):
        meta = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
        dc = DataContainer.read(str(path))
        n, t, start = meta["n_atoms"], meta["temperature"], meta["production_start"]
        df = dc.data
        prod = df.loc[df.mctrial > start].copy()
        energy = prod.potential.dropna().to_numpy()
        if len(energy) < 2:
            raise ValueError(f"Too few production samples: {path}")
        rec = dict(file=path.name, T_K=t, n_atoms=n, seed=meta["seed"],
                   n_samples=len(energy), energy_eV_atom=energy.mean()/n,
                   cv_config_eV_atom_K=np.var(energy, ddof=1)/(n*kB*t*t))
        # Analysis includes correlation information; start is a trial-step value, not a row number.
        stats = dc.analyze_data("potential", start=start + 1)
        rec["energy_error95_eV_atom"] = stats["error_estimate"] / n
        rec["energy_correlation_length_samples"] = stats["correlation_length"]
        for col in prod:
            if col.startswith("sro_"):
                rec[col] = prod[col].dropna().mean()
        records.append(rec)
        df.to_csv(path.with_suffix(".csv"), index=False)
    if not records:
        raise ValueError("No .dc files found")
    summary = pd.DataFrame(records).sort_values("T_K")
    summary.to_csv(a.directory / "summary.csv", index=False)
    print(summary.to_string(index=False))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 1, figsize=(6, 6), sharex=True)
    axes[0].errorbar(summary.T_K, summary.energy_eV_atom*1000,
                     yerr=summary.energy_error95_eV_atom*1000, fmt="o")
    axes[0].set_ylabel("Energy (meV/atom)")
    axes[1].plot(summary.T_K, summary.cv_config_eV_atom_K/kB, "o")
    axes[1].set_ylabel("Configurational Cv (kB/atom)")
    axes[1].set_xlabel("Temperature (K)")
    fig.tight_layout()
    fig.savefig(a.directory / "canonical_summary.png", dpi=180)


if __name__ == "__main__":
    main()

