"""Fit a CE from an ASE database containing ideal-lattice structures.

For AgPd: use the official reference_data.db and --key mixing_energy.
For HEAs: provide a primitive cell, symbols, cutoffs and the documented schema.
The selected property MUST already be in eV per lattice site (fully occupied: atom).
"""
import argparse
from pathlib import Path
from importlib.metadata import version
import numpy as np
from ase.db import connect
from ase.io import read
from icet import ClusterSpace, StructureContainer, ClusterExpansion
from trainstation import CrossValidationEstimator


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("database", type=Path)
    p.add_argument("--primitive", type=Path, help="Required except for official AgPd database")
    p.add_argument("--symbols", nargs="+", default=["Ag", "Pd"])
    p.add_argument("--cutoffs", nargs="+", type=float, default=[13.5, 6.5, 6.0])
    p.add_argument("--key", default="mixing_energy")
    p.add_argument("--out", type=Path, default=Path("fit_agpd"))
    a = p.parse_args()
    if not a.database.is_file():
        raise FileNotFoundError(a.database)
    if a.out.exists():
        raise FileExistsError(f"Choose a new output directory: {a.out}")
    db = connect(str(a.database))
    if a.primitive is None and set(a.symbols) != {"Ag", "Pd"}:
        raise ValueError("Supply --primitive for your own dataset")
    primitive = read(str(a.primitive)) if a.primitive else db.get(id=1).toatoms()
    cs = ClusterSpace(primitive, a.cutoffs, a.symbols)
    sc = StructureContainer(cs)
    ids = []
    for row in db.select():
        structure = row.toatoms()
        cs.assert_structure_compatibility(structure)
        value = float(row[a.key])
        if not np.isfinite(value):
            raise ValueError(f"Non-finite target in row {row.id}")
        sc.add_structure(structure, user_tag=f"row_{row.id}",
                         properties={"energy": value})
        ids.append(row.id)
    A, y = sc.get_fit_data(key="energy")
    if len(y) < 10:
        raise ValueError("This 5-fold example requires at least 10 structures")
    opt = CrossValidationEstimator((A, y), fit_method="ardr", n_splits=5, seed=42)
    opt.validate()
    opt.train()
    ce = ClusterExpansion(cs, opt.parameters, metadata={
        "target_units": "eV/site", "target_key": a.key,
        "reference_energy_convention": "See the accompanying dataset manifest",
        "icet_version": version("icet"), "validation": str(opt),
    })
    a.out.mkdir(parents=True)
    ce.write(str(a.out / "model.ce"))
    sc.write(str(a.out / "training.sc"))
    np.savetxt(a.out / "fit_in_sample.csv", np.column_stack([ids, y, A @ opt.parameters]),
               delimiter=",", header="row_id,target_eV_site,predicted_eV_site", comments="")
    (a.out / "validation.txt").write_text(str(opt) + "\n", encoding="utf-8")
    print(cs)
    print(opt)
    print("CV RMSE (meV/site):", 1000 * opt.rmse_validation)
    print("fit_in_sample.csv is NOT an independent test set.")


if __name__ == "__main__":
    main()

